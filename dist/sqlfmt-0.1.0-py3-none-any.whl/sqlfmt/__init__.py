from pathlib import Path

__version__ = "0.2.0"
ROOT_DIR = Path(__file__).resolve().parent.parent.parent
